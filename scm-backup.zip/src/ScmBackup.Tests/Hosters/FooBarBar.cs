﻿namespace ScmBackup.Tests.Hosters
{
    /// <summary>
    /// test class for HosterNameHelperTests.ThrowsWhenTypeNameContainsSuffixMoreThanOnce
    /// </summary>
    public class FooBarBar
    {
    }
}
