﻿namespace ScmBackup
{
    internal interface IScmBackup
    {
        bool Run();
    }
}
