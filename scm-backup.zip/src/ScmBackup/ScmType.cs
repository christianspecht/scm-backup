﻿namespace ScmBackup
{
    /// <summary>
    /// Supported SCMs
    /// </summary>
    internal enum ScmType
    {
        Git,
        Mercurial
    }
}
