﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ScmBackup.Hosters.Gitlab
{
    class GitlabApiWiki
    {
        public string slug { get; set; }
    }
}
